import {defineConfig,devices} from '@playwright/test';
export default defineConfig({testDir:'./e2e',use:{baseURL:'http://localhost:3000',trace:'on-first-retry'},projects:[{name:'chromium',use:{...devices['Desktop Chrome']}}],webServer:{command:'pnpm dev',url:'http://localhost:3000/en',reuseExistingServer:true}});
